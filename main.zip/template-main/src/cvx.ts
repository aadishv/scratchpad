import { api } from "../convex/_generated/api";

export default api;
